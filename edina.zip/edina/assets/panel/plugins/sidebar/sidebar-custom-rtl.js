$(function() {
  'use strict';
	// ______________ PerfectScrollbar	
	const ps1 = new PerfectScrollbar('.sidebar-left', {
		useBothWheelAxes:false,
		suppressScrollX:false,
	});

});