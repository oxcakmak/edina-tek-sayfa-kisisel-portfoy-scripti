$(function() {
  'use strict';
	// ______________ PerfectScrollbar	
	const ps1 = new PerfectScrollbar('.sidebar-right', {
		useBothWheelAxes:true,
		suppressScrollX:true,
	});

});