(function($) {
	"use strict";
	
	// ______________ PerfectScrollbar
	const ps = new PerfectScrollbar('.first-sidemenu', {
		useBothWheelAxes:false,
		suppressScrollX:false,
	});
	const ps1 = new PerfectScrollbar('.second-sidemenu', {
		useBothWheelAxes:false,
		suppressScrollX:false,
	});
	
})(jQuery);